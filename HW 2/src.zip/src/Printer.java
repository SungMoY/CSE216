/**
 * DO NOT CHANGE THIS CODE
 */
public class Printer<TwoDShape> extends AbstractPrinter<TwoDShape> {
    @Override
    void print(TwoDShape s) {
        System.out.println(s);
    }
}
