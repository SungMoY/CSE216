import java.util.*;
import java.util.stream.Collectors;

public class StreamUtils {

    public static Collection<String> capitalized(Collection<String> strings) {
        return strings.stream()
                .filter(currentString -> currentString != null)
                .filter(currentString -> Character.isUpperCase(currentString.charAt(0)))
                .collect(Collectors.toList());
    }

    public static String longest(Collection<String> strings, boolean from_start) {
        return strings.stream()
                .filter(currentString -> currentString != null)
                .reduce((stringOne, stringTwo) -> from_start ?
                        ((stringOne.length() == stringTwo.length() ?
                                stringOne :
                                (stringOne.length() > stringTwo.length() ?
                                        stringOne :
                                        stringTwo))) :
                        ((stringOne.length() == stringTwo.length() ?
                                stringTwo :
                                (stringOne.length() > stringTwo.length() ?
                                        stringOne :
                                        stringTwo))))
                .orElse(null);
    }

    public static <T extends Comparable<T>> T least(Collection<T> items, boolean from_start) {
        return items.stream()
                .filter(currentObject -> currentObject != null)
                .reduce((objectOne, objectTwo) -> from_start ?
                        ((objectOne.compareTo(objectTwo) == 0 ?
                                objectOne :
                                (objectOne.compareTo(objectTwo) < 0 ?
                                        objectOne :
                                        objectTwo))) :
                        ((objectOne.compareTo(objectTwo) == 0 ?
                                objectTwo :
                                (objectOne.compareTo(objectTwo) < 0 ?
                                        objectOne :
                                        objectTwo))))
                .orElse(null);
    }

    public static <K, V> List<String> flatten(Map<K, V> aMap) {
        return aMap
                .keySet()
                .stream()
                .map(currentKey -> (currentKey + " -> " + aMap.get(currentKey)))
                .collect(Collectors.toList());
    }
}
