import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.BiFunction;
import java.util.function.Function;

public class HigherOrderUtils {

    public static interface NamedBiFunction<T,U,R> extends BiFunction<T,U,R> {
        String name();
    }

    public static NamedBiFunction<Double, Double, Double> add = new NamedBiFunction<Double, Double,Double>() {
        @Override
        public Double apply(Double doubleOne, Double doubleTwo) {
            return doubleOne+doubleTwo;
        }
        @Override
        public String name() {
            return "add";
        }
    };

    public static NamedBiFunction<Double, Double, Double> subtract = new NamedBiFunction<Double, Double,Double>() {
        @Override
        public Double apply(Double doubleOne, Double doubleTwo) {
            return doubleOne-doubleTwo;
        }
        @Override
        public String name() {
            return "diff";
        }
    };

    public static NamedBiFunction<Double, Double, Double> multiply = new NamedBiFunction<Double, Double,Double>() {
        @Override
        public Double apply(Double doubleOne, Double doubleTwo) {
            return doubleOne*doubleTwo;
        }
        @Override
        public String name() {
            return "mult";
        }
    };

    public static NamedBiFunction<Double, Double, Double> divide = new NamedBiFunction<Double, Double,Double>() {
        @Override
        public Double apply(Double doubleOne, Double doubleTwo) {
            if (doubleTwo == 0){
                throw new ArithmeticException("Error: Division by 0");
            }
            return Double.valueOf(doubleOne.intValue()/doubleTwo.intValue());
        }
        @Override
        public String name() {
            return "div";
        }
    };

    public static <T> T zip(List<T> args, List<NamedBiFunction<T, T, T>> bifunctions) {
        if (bifunctions.size() >= args.size()) {
            throw new IllegalArgumentException("Error: There cannot be less arguments than operations");
        }
        for (int i = 0; i < bifunctions.size(); i++) {
            args.set(i+1, bifunctions.get(i).apply(args.get(i), args.get(i+1)));

        }
        return args.get(args.size()-1);
    }

    public static class FunctionComposition<T, U, R> {
        public BiFunction<Function<T, U>, Function<U, R>, Function<T, R>> composition = (TtoUFunction, UtoRFunction) -> TtoUFunction.andThen(UtoRFunction);
    }
}
